with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('id="mobile-app"')
if idx != -1:
    print(text[idx+1800:idx+3800])
