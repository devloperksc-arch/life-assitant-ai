const fs = require('fs');

global.window = global;
global.window.scrollTo = () => {};
global.document = {
  getElementById: (id) => ({ innerHTML: '', classList: { add: ()=>{}, remove: ()=>{} }, style: {} }),
  activeElement: null,
  addEventListener: () => {},
  documentElement: { scrollTop: 0 },
  body: { scrollTop: 0 },
  querySelector: () => null,
  querySelectorAll: () => []
};
global.localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };

eval(fs.readFileSync('js/data.js', 'utf8'));
eval(fs.readFileSync('js/db.js', 'utf8'));
eval(fs.readFileSync('js/utils.js', 'utf8'));
eval(fs.readFileSync('js/lib/ai.js', 'utf8'));
eval(fs.readFileSync('js/domain-pages.js', 'utf8'));

console.log('window.DOMAINS count:', window.DOMAINS.length);
