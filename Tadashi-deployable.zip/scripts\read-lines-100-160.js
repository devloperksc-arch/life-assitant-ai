const fs = require('fs');
const lines = fs.readFileSync('js/domain-pages.js', 'utf8').split('\n');
console.log(lines.slice(100, 160).join('\n'));
