const fs = require('fs');
const dp = fs.readFileSync('js/domain-pages.js', 'utf8');

const idx = dp.indexOf('const ALIAS_MAP = {');
console.log('ALIAS_MAP:');
if (idx !== -1) {
  console.log(dp.substring(idx, idx + 1000));
}
