const fs = require('fs');
const dp = fs.readFileSync('js/domain-pages.js', 'utf8');

const matches = [...dp.matchAll(/domain-ai-prompt/g)];
console.log('Matches for domain-ai-prompt:', matches.length);
for (const m of matches) {
  const i = m.index;
  console.log(dp.substring(Math.max(0, i - 50), Math.min(dp.length, i + 200)));
  console.log('---');
}
