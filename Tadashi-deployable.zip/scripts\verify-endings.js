const fs = require('fs');

function checkLineEnding(path) {
  const buf = fs.readFileSync(path);
  const crlfCount = (buf.toString().match(/\r\n/g) || []).length;
  const lfOnlyCount = (buf.toString().replace(/\r\n/g, '').match(/\n/g) || []).length;
  console.log(`${path}: CRLF=${crlfCount}, LF_only=${lfOnlyCount} -> ${crlfCount > 0 && lfOnlyCount === 0 ? 'STRICT CRLF' : (crlfCount === 0 ? 'STRICT LF' : 'MIXED')}`);
}

checkLineEnding('index.html');
checkLineEnding('js/domain-pages.js');
