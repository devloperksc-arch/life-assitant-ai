const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const idx = html.indexOf("const grid = document.getElementById('mobile-domains-grid');");
if (idx !== -1) {
  console.log(html.substring(idx - 50, idx + 800));
}
