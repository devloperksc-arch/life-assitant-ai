const fs = require('fs');
const dp = fs.readFileSync('js/domain-pages.js', 'utf8');

const idx = dp.indexOf('function normalizeDomainId');
console.log('normalizeDomainId index:', idx);
if (idx !== -1) {
  console.log(dp.substring(idx - 100, idx + 800));
}
