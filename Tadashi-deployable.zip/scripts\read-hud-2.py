with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('id="hud-subbar"')
if idx != -1:
    print(text[idx+500:idx+1500])
