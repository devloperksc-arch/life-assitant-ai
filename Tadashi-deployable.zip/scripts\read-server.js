const fs = require('fs');
const code = fs.readFileSync('scripts/static-server.js', 'utf8');
console.log(code);
