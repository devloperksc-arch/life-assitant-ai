const fs = require('fs');
const dp = fs.readFileSync('js/domain-pages.js', 'utf8');

const idx = dp.indexOf('function _doRenderDomainPage');
console.log(dp.substring(idx, idx + 800));
console.log('--- bottom of _doRenderDomainPage ---');
const idxEnd = dp.indexOf('// Render into active container', idx);
console.log(dp.substring(idxEnd, idxEnd + 800));
