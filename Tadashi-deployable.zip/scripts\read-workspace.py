with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('id="view-workspace"')
print(f'Index of id="view-workspace": {idx}')
if idx != -1:
    print(text[idx:idx+2500])
