const fs = require('fs');

// Minimal DOM environment
class ElementMock {
  constructor(id, tag = 'div') {
    this.id = id;
    this.tagName = tag.toUpperCase();
    this.classList = {
      _set: new Set(),
      add: function(c) { this._set.add(c); },
      remove: function(c) { this._set.delete(c); },
      contains: function(c) { return this._set.has(c); },
      toggle: function(c, force) { if (force) this._set.add(c); else this._set.delete(c); }
    };
    this.style = {};
    this.innerHTML = '';
  }
}

const elements = {
  'desktop-app': new ElementMock('desktop-app'),
  'mobile-app': new ElementMock('mobile-app'),
  'view-domain-page': new ElementMock('view-domain-page'),
  'mobile-domain-view-content': new ElementMock('mobile-domain-view-content'),
  'hud-subbar': new ElementMock('hud-subbar'),
  'mobile-domains-modal': new ElementMock('mobile-domains-modal'),
  'mobile-domain-view': new ElementMock('mobile-domain-view'),
  'view-manage': new ElementMock('view-manage'),
  'view-workspace': new ElementMock('view-workspace'),
  'view-tadashi': new ElementMock('view-tadashi')
};

global.window = global;
global.window.innerWidth = 1280;
global.window.matchMedia = (q) => ({ matches: false });
global.window.scrollTo = () => {};
global.document = {
  getElementById: (id) => elements[id] || null,
  querySelector: (sel) => elements['desktop-app'],
  querySelectorAll: (sel) => Object.values(elements),
  addEventListener: () => {},
  activeElement: null,
  documentElement: { scrollTop: 0 },
  body: { scrollTop: 0 }
};
global.localStorage = {
  _store: {},
  getItem: (k) => global.localStorage._store[k] || null,
  setItem: (k, v) => { global.localStorage._store[k] = String(v); },
  removeItem: (k) => { delete global.localStorage._store[k]; }
};

// Load live scripts in order
eval(fs.readFileSync('js/data.js', 'utf8'));
eval(fs.readFileSync('js/db.js', 'utf8'));
eval(fs.readFileSync('js/utils.js', 'utf8'));
eval(fs.readFileSync('js/lib/ai.js', 'utf8'));
eval(fs.readFileSync('js/domain-pages.js', 'utf8'));

// Test opening all 23 domains
const domains = window.DOMAINS || [];
console.log(`Found ${domains.length} domains in DOMAINS registry.`);

let failedCount = 0;
for (const d of domains) {
  try {
    elements['view-domain-page'].innerHTML = '';
    window.openDomainPage(d.id, false);
    const htmlLen = elements['view-domain-page'].innerHTML.length;
    if (htmlLen === 0) {
      console.error(`FAILED: Domain "${d.id}" rendered EMPTY innerHTML!`);
      failedCount++;
    } else {
      console.log(`OK: Domain [${d.num}] "${d.id}" rendered ${htmlLen} chars.`);
    }
  } catch (err) {
    console.error(`ERROR opening domain "${d.id}":`, err);
    failedCount++;
  }
}

console.log(`\nResult: ${domains.length - failedCount}/${domains.length} passed.`);
