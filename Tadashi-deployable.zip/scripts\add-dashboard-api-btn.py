# Update index.html and js/domain-pages.js to add API Key buttons on Dashboard
import re

print("Updating index.html...")
with open('index.html', 'rb') as f:
    raw_html = f.read()

is_crlf_html = b'\r\n' in raw_html
html_text = raw_html.decode('utf-8').replace('\r\n', '\n')

# 1. Desktop #view-workspace synthesis banner
desktop_target = """<button class="px-5 py-2.5 rounded-xl glass-surface hover:bg-surface-container/60 text-on-surface font-mono text-xs transition-all flex items-center gap-2 active:scale-95 border border-outline-variant/30" onclick="switchTab('view-schedule')">
<span class="material-symbols-outlined text-outline text-[18px]">tune</span>
<span class="">Adjust Schedule</span>
</button>
</div>"""

desktop_replacement = """<button class="px-5 py-2.5 rounded-xl glass-surface hover:bg-surface-container/60 text-on-surface font-mono text-xs transition-all flex items-center gap-2 active:scale-95 border border-outline-variant/30" onclick="switchTab('view-schedule')">
<span class="material-symbols-outlined text-outline text-[18px]">tune</span>
<span class="">Adjust Schedule</span>
</button>
<button class="px-4 py-2.5 rounded-xl glass-surface hover:bg-surface-container/80 text-white font-mono text-xs font-semibold transition-all flex items-center gap-2 active:scale-95 border border-primary-container/40 hover:border-primary-container shadow-[0_0_14px_rgba(0,212,255,0.18)]" onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" title="Configure or switch API Keys (Gemini, Claude, ChatGPT, OpenRouter)">
<span class="material-symbols-outlined text-primary-container text-[18px]">key</span>
<span class="">Change API Key</span>
</button>
</div>"""

if desktop_target in html_text:
    html_text = html_text.replace(desktop_target, desktop_replacement, 1)
    print("Added Change API Key button to Desktop Workspace hero card!")
else:
    print("WARNING: desktop_target not found!")

# 2. Desktop #hud-subbar status pills
hud_target = """<button class="hover:text-primary-container transition-colors flex items-center gap-1 px-2 py-1 rounded-md" onclick="switchTab('view-manage')">
<span class="">23 Domains Active</span>
<span class="material-symbols-outlined text-[14px]">arrow_forward</span>
</button>
</div>"""

hud_replacement = """<button class="hover:text-primary-container transition-colors flex items-center gap-1 px-2 py-1 rounded-md" onclick="switchTab('view-manage')">
<span class="">23 Domains Active</span>
<span class="material-symbols-outlined text-[14px]">arrow_forward</span>
</button>
<button class="hover:text-primary-container transition-colors flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-surface-container-low border border-primary-container/30 hover:border-primary-container/60 text-white text-[11px] font-mono shadow-[0_0_10px_rgba(0,212,255,0.12)] active:scale-95" onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" title="Configure or change AI Provider API Keys">
<span class="material-symbols-outlined text-primary-container text-[13px]">key</span>
<span>API Key</span>
</button>
</div>"""

if hud_target in html_text:
    html_text = html_text.replace(hud_target, hud_replacement, 1)
    print("Added API Key pill to HUD sub-bar!")
else:
    print("WARNING: hud_target not found!")

# 3. Mobile synthesis priority banner
mobile_target = """<!-- Adjust Schedule Button -->
<button onclick="scrollToMobileFlow()" class="flex items-center space-x-1.5 py-2.5 px-3 rounded-xl bg-slate-900/80 border border-slate-700/70 text-slate-200 font-medium text-xs hover:border-slate-600 active:scale-[0.98] transition-transform">
<svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewbox="0 0 24 24">
<path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
<span>Adjust Schedule</span>
</button>
</div>"""

mobile_replacement = """<!-- Adjust Schedule Button -->
<button onclick="scrollToMobileFlow()" class="flex items-center space-x-1.5 py-2.5 px-3 rounded-xl bg-slate-900/80 border border-slate-700/70 text-slate-200 font-medium text-xs hover:border-slate-600 active:scale-[0.98] transition-transform">
<svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewbox="0 0 24 24">
<path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
</svg>
<span>Adjust Schedule</span>
</button>
<!-- Change API Key Button -->
<button onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" class="flex items-center space-x-1.5 py-2.5 px-3 rounded-xl bg-slate-900/80 border border-cyan-500/40 text-cyan-400 hover:text-white font-medium text-xs hover:border-cyan-400 active:scale-[0.98] transition-transform" title="Change API Key">
<span class="material-symbols-outlined text-[15px]">key</span>
<span>API Key</span>
</button>
</div>"""

if mobile_target in html_text:
    html_text = html_text.replace(mobile_target, mobile_replacement, 1)
    print("Added API Key button to Mobile synthesis banner!")
else:
    print("WARNING: mobile_target not found!")

# Bump cache-buster from 5.13 to 5.14 in index.html
html_text = re.sub(r'\?v=5\.13', '?v=5.14', html_text)
print("Bumped cache-buster to ?v=5.14")

if is_crlf_html:
    out_html = html_text.replace('\n', '\r\n').encode('utf-8')
else:
    out_html = html_text.encode('utf-8')

with open('index.html', 'wb') as f:
    f.write(out_html)
print("index.html written successfully!")


# Now update js/domain-pages.js (renderHomeDomain)
print("\nUpdating js/domain-pages.js...")
with open('js/domain-pages.js', 'rb') as f:
    raw_dp = f.read()

is_crlf_dp = b'\r\n' in raw_dp
dp_text = raw_dp.decode('utf-8').replace('\r\n', '\n')

home_target = """          <div class="flex items-center justify-between pb-2 border-b border-outline-variant/10">
            <h4 class="text-sm font-bold text-white flex items-center gap-2">
              <span class="material-symbols-outlined text-primary-container text-[18px]">bolt</span>
              Urgent Priority Action Items
            </h4>
            <span class="text-[10px] font-mono text-outline">Auto-Triaged</span>
          </div>"""

home_replacement = """          <div class="flex items-center justify-between pb-2 border-b border-outline-variant/10">
            <h4 class="text-sm font-bold text-white flex items-center gap-2">
              <span class="material-symbols-outlined text-primary-container text-[18px]">bolt</span>
              Urgent Priority Action Items
            </h4>
            <div class="flex items-center gap-2">
              <button onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" class="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-primary-container/15 hover:bg-primary-container/25 border border-primary-container/30 text-primary-container font-mono text-[11px] font-semibold active:scale-95 transition-all" title="Change or configure API Key">
                <span class="material-symbols-outlined text-[14px]">key</span>
                <span>Change API Key</span>
              </button>
              <span class="text-[10px] font-mono text-outline">Auto-Triaged</span>
            </div>
          </div>"""

if home_target in dp_text:
    dp_text = dp_text.replace(home_target, home_replacement, 1)
    print("Added Change API Key button to Home Dashboard domain page!")
else:
    print("WARNING: home_target not found in js/domain-pages.js!")

if is_crlf_dp:
    out_dp = dp_text.replace('\n', '\r\n').encode('utf-8')
else:
    out_dp = dp_text.encode('utf-8')

with open('js/domain-pages.js', 'wb') as f:
    f.write(out_dp)
print("js/domain-pages.js written successfully!")
