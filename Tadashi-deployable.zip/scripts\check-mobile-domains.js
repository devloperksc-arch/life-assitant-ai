const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const mobileStart = html.indexOf('id="mobile-app"');
const mobileHtml = html.substring(mobileStart);
const matches = [...mobileHtml.matchAll(/openDomainPage\('([^']+)'\)/g)];
console.log('Mobile openDomainPage calls count:', matches.length);
console.log('Mobile domains called:', matches.map(m => m[1]));

// Also check mobile-domains-modal
const modalIdx = html.indexOf('id="mobile-domains-modal"');
console.log('mobile-domains-modal found?', modalIdx !== -1);
if (modalIdx !== -1) {
  console.log(html.substring(modalIdx, modalIdx + 1500));
}
