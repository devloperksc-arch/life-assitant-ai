const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');

const regex = /openDomainPage\s*\(([^)]*)\)/g;
let m;
const calls = [];
while ((m = regex.exec(html)) !== null) {
  const lineNo = html.substring(0, m.index).split('\n').length;
  calls.push({ line: lineNo, arg: m[1].trim(), snippet: html.substring(Math.max(0, m.index - 50), Math.min(html.length, m.index + 80)) });
}
console.log(`Total openDomainPage calls in index.html: ${calls.length}`);
for (const c of calls) {
  console.log(`Line ${c.line}: openDomainPage(${c.arg})`);
}
