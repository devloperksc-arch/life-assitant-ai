const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');

const start = html.indexOf('id="view-workspace"');
const end = html.indexOf('id="view-tadashi"');
console.log('view-workspace length:', end - start);
console.log(html.substring(start, start + 3000));
