const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');
const idx = html.indexOf('mobile-domains-grid');
while (idx !== -1) {
  console.log('mobile-domains-grid match:');
  console.log(html.substring(Math.max(0, idx - 100), Math.min(html.length, idx + 400)));
  break;
}

// Find where mobile-domains-grid is used in scripts
const scriptMatches = [...html.matchAll(/mobile-domains-grid/g)];
console.log('Total occurrences in index.html:', scriptMatches.length);
for (const m of scriptMatches) {
  const i = m.index;
  console.log(html.substring(Math.max(0, i - 100), Math.min(html.length, i + 300)));
  console.log('---');
}
