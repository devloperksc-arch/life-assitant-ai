with open('index.html', 'r', encoding='utf-8') as f:
    text = f.read()

idx = text.find('synthesis-priority-banner')
if idx != -1:
    print(text[idx+1400:idx+2500])
