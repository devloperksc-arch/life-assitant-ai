# Comprehensive fix for domain opening and dashboard API key button
import re

print("=== [1] Updating scripts/static-server.js with no-cache headers ===")
with open('scripts/static-server.js', 'r', encoding='utf-8') as f:
    server_code = f.read()

old_res_head = """    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'Access-Control-Allow-Origin': '*'
    });"""

new_res_head = """    const isHtmlOrJs = ext === '.html' || ext === '.js';
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': isHtmlOrJs ? 'no-cache, no-store, must-revalidate' : 'public, max-age=3600',
      'Pragma': 'no-cache',
      'Expires': '0'
    });"""

if old_res_head in server_code:
    server_code = server_code.replace(old_res_head, new_res_head)
    with open('scripts/static-server.js', 'w', encoding='utf-8') as f:
        f.write(server_code)
    print("scripts/static-server.js updated with no-cache headers!")
else:
    print("static-server target not found, skipping...")


print("\n=== [2] Updating js/domain-pages.js ===")
with open('js/domain-pages.js', 'rb') as f:
    raw_dp = f.read()

is_crlf_dp = b'\r\n' in raw_dp
dp_text = raw_dp.decode('utf-8').replace('\r\n', '\n')

# Fix 1: openDomainPage view-panel display handling
old_open_panel = """    // Desktop view switching
    if (typeof window.switchTab === 'function') {
      try { window.switchTab('view-domain-page', false); } catch (e) { }
    }
    document.querySelectorAll('.view-panel').forEach(p => {
      p.classList.add('panel-hidden');
      p.style.display = '';
    });
    const target = document.getElementById('view-domain-page');
    if (target) {
      target.classList.remove('panel-hidden');
      target.classList.remove('hidden');
      target.style.display = '';
    }"""

new_open_panel = """    // Desktop view switching: unconditionally activate #view-domain-page
    if (typeof window.switchTab === 'function') {
      try { window.switchTab('view-domain-page', false); } catch (e) { }
    }
    document.querySelectorAll('.view-panel').forEach(p => {
      if (p.id !== 'view-domain-page') {
        p.classList.add('panel-hidden');
        p.style.display = 'none';
      }
    });
    const target = document.getElementById('view-domain-page');
    if (target) {
      target.classList.remove('panel-hidden');
      target.classList.remove('hidden');
      target.style.display = 'block';
    }"""

if old_open_panel in dp_text:
    dp_text = dp_text.replace(old_open_panel, new_open_panel, 1)
    print("Fixed openDomainPage view panel display toggles!")
else:
    print("WARNING: old_open_panel not matched in domain-pages.js")

# Fix 2: Render into BOTH containers in _doRenderDomainPage (never wipe either container!)
old_render_containers = """    // Render into active container based on layout (prevents duplicate IDs between desktop & mobile)
    let isMobile = false;
    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      try { isMobile = window.matchMedia('(max-width: 1023px)').matches; } catch (e) { }
    }

    if (isMobile && mobileContainer) {
      mobileContainer.innerHTML = renderedHtml;
      if (container) container.innerHTML = '';
    } else if (container) {
      container.innerHTML = renderedHtml;
      if (mobileContainer) mobileContainer.innerHTML = '';
    } else if (mobileContainer) {
      mobileContainer.innerHTML = renderedHtml;
    }"""

new_render_containers = """    // Always render into BOTH containers so content is immediately ready regardless of viewport/scaling!
    if (container) {
      container.innerHTML = renderedHtml;
    }
    if (mobileContainer) {
      mobileContainer.innerHTML = renderedHtml;
    }"""

if old_render_containers in dp_text:
    dp_text = dp_text.replace(old_render_containers, new_render_containers, 1)
    print("Fixed _doRenderDomainPage container wiping - now renders to both containers safely!")
else:
    print("WARNING: old_render_containers not matched in domain-pages.js")

# Fix 3: Execute pending domain open queue at the bottom of domain-pages.js
old_expose = """  // Expose to window
  window.openDomainPage = openDomainPage;
  window.renderDomainPage = renderDomainPage;
  window.returnToDomainsHub = returnToDomainsHub;"""

new_expose = """  // Expose to window
  window._realOpenDomainPage = openDomainPage;
  window.openDomainPage = openDomainPage;
  window.renderDomainPage = renderDomainPage;
  window.returnToDomainsHub = returnToDomainsHub;

  // If a domain open request was queued before this file finished loading, execute immediately
  if (typeof window !== 'undefined' && window._pendingDomainOpen) {
    const pending = window._pendingDomainOpen;
    window._pendingDomainOpen = null;
    try { openDomainPage(pending.id, pending.pushHistory); } catch (e) { }
  }"""

if old_expose in dp_text:
    dp_text = dp_text.replace(old_expose, new_expose, 1)
    print("Added _realOpenDomainPage and queued open handler!")
else:
    print("WARNING: old_expose not matched in domain-pages.js")

if is_crlf_dp:
    out_dp = dp_text.replace('\n', '\r\n').encode('utf-8')
else:
    out_dp = dp_text.encode('utf-8')

with open('js/domain-pages.js', 'wb') as f:
    f.write(out_dp)
print("js/domain-pages.js written successfully!")


print("\n=== [3] Updating index.html ===")
with open('index.html', 'rb') as f:
    raw_html = f.read()

is_crlf_html = b'\r\n' in raw_html
html_text = raw_html.decode('utf-8').replace('\r\n', '\n')

# 1. Add global queue stub in <head> before anything else so openDomainPage is ALWAYS defined
stub_script = """  <script>
    // Stub openDomainPage early so clicks before domain-pages.js finishes loading never throw ReferenceError
    window.openDomainPage = function(id, pushHistory = true) {
      if (typeof window._realOpenDomainPage === 'function') {
        return window._realOpenDomainPage(id, pushHistory);
      }
      window._pendingDomainOpen = { id, pushHistory };
    };
  </script>
</head>"""

if '</head>' in html_text and 'window._pendingDomainOpen' not in html_text:
    html_text = html_text.replace('</head>', stub_script, 1)
    print("Added early openDomainPage queue stub in <head>!")

# 2. Fix syncRouteFromHash in index.html to queue when openDomainPage not yet loaded
old_sync_route = """      const matchedDomain = domainsList.find(d => d.id === hash || d.id === normDomain);
      if (matchedDomain) {
        if (typeof window.openDomainPage === 'function') {
          window.openDomainPage(matchedDomain.id, pushHistory);
          return;
        }
      }"""

new_sync_route = """      const matchedDomain = domainsList.find(d => d.id === hash || d.id === normDomain);
      if (matchedDomain) {
        if (typeof window._realOpenDomainPage === 'function' || typeof window.openDomainPage === 'function') {
          window.openDomainPage(matchedDomain.id, pushHistory);
          return;
        } else {
          window._pendingDomainOpen = { id: matchedDomain.id, pushHistory };
          return;
        }
      }"""

if old_sync_route in html_text:
    html_text = html_text.replace(old_sync_route, new_sync_route, 1)
    print("Fixed syncRouteFromHash to queue pending domain opens!")
else:
    print("WARNING: old_sync_route not matched in index.html")

# 3. Add prominent, unmissable Change API Key buttons on Dashboard (Workspace view)
# In synthesis priority banner
old_buttons = """<button class="px-5 py-2.5 rounded-xl bg-primary-container text-surface-container-lowest font-mono text-xs font-bold hover:bg-surface-tint transition-all cyan-glow flex items-center gap-2 active:scale-95" onclick="togglePlayAudio()">
<span class="material-symbols-outlined text-surface-container-lowest text-[18px]" style="font-variation-settings: 'FILL' 1;">graphic_eq</span>
<span class="">Live Audio Briefing</span>
</button>
<button class="px-5 py-2.5 rounded-xl glass-surface hover:bg-surface-container/60 text-on-surface font-mono text-xs transition-all flex items-center gap-2 active:scale-95 border border-outline-variant/30" onclick="switchTab('view-schedule')">
<span class="material-symbols-outlined text-outline text-[18px]">tune</span>
<span class="">Adjust Schedule</span>
</button>"""

new_buttons = """<button class="px-5 py-2.5 rounded-xl bg-primary-container text-surface-container-lowest font-mono text-xs font-bold hover:bg-surface-tint transition-all cyan-glow flex items-center gap-2 active:scale-95" onclick="togglePlayAudio()">
<span class="material-symbols-outlined text-surface-container-lowest text-[18px]" style="font-variation-settings: 'FILL' 1;">graphic_eq</span>
<span class="">Live Audio Briefing</span>
</button>
<button class="px-5 py-2.5 rounded-xl glass-surface hover:bg-surface-container/60 text-on-surface font-mono text-xs transition-all flex items-center gap-2 active:scale-95 border border-outline-variant/30" onclick="switchTab('view-schedule')">
<span class="material-symbols-outlined text-outline text-[18px]">tune</span>
<span class="">Adjust Schedule</span>
</button>
<button class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary-container/25 via-primary-container/20 to-secondary-container/20 text-white font-mono text-xs font-bold hover:border-primary-container cyan-glow transition-all flex items-center gap-2 active:scale-95 border border-primary-container/60 shadow-[0_0_20px_rgba(0,212,255,0.25)]" onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" title="Configure or switch API Keys (Gemini, Claude, ChatGPT, OpenRouter)">
<span class="material-symbols-outlined text-primary-container text-[18px]">vpn_key</span>
<span class="text-primary-container font-extrabold tracking-wide">Change API Key</span>
</button>"""

if old_buttons in html_text:
    html_text = html_text.replace(old_buttons, new_buttons, 1)
    print("Added highlighted Change API Key button to Dashboard synthesis banner!")
else:
    print("Note: old_buttons pattern not exact, checking if button already present...")

# 4. Also add a dedicated Quick Access Strip right above the Action Matrix on Dashboard
matrix_header_target = """<!-- ACTION SUMMARY CHIPS: Priority 4-Card Action Matrix -->
<section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">"""

matrix_header_replacement = """<!-- Dashboard Quick Actions & API Key Strip -->
<div class="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl glass-surface border border-primary-container/25 shadow-lg bg-surface-container-lowest/60">
  <div class="flex items-center gap-2.5">
    <div class="w-8 h-8 rounded-xl bg-primary-container/20 border border-primary-container/40 flex items-center justify-center text-primary-container">
      <span class="material-symbols-outlined text-[18px]">smart_toy</span>
    </div>
    <div>
      <p class="text-xs font-bold text-white flex items-center gap-2">
        TADASHI Neural Bridge
        <span class="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-primary-container/15 text-primary-container border border-primary-container/30">Multi-Provider AI Active</span>
      </p>
      <p class="text-[10px] text-outline font-mono">Connect Google Gemini, Anthropic Claude, OpenAI ChatGPT, or OpenRouter</p>
    </div>
  </div>
  <div class="flex items-center gap-2">
    <button onclick="if(typeof openApiKeyModal==='function')openApiKeyModal();" class="px-4 py-2 rounded-xl bg-primary-container text-black font-mono text-xs font-bold hover:bg-surface-tint cyan-glow active:scale-95 transition-all flex items-center gap-1.5 shadow-[0_0_16px_rgba(0,212,255,0.3)]">
      <span class="material-symbols-outlined text-[16px]">key</span>
      <span>Change API Key</span>
    </button>
  </div>
</div>

<!-- ACTION SUMMARY CHIPS: Priority 4-Card Action Matrix -->
<section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">"""

if matrix_header_target in html_text:
    html_text = html_text.replace(matrix_header_target, matrix_header_replacement, 1)
    print("Added dedicated Neural Bridge & Change API Key banner above Action Matrix on Dashboard!")
else:
    print("WARNING: matrix_header_target not found in index.html!")

# Bump cache buster to 5.15
html_text = re.sub(r'\?v=5\.\d+', '?v=5.15', html_text)
print("Bumped cache-buster to ?v=5.15 across all scripts in index.html")

if is_crlf_html:
    out_html = html_text.replace('\n', '\r\n').encode('utf-8')
else:
    out_html = html_text.encode('utf-8')

with open('index.html', 'wb') as f:
    f.write(out_html)
print("index.html written successfully!")
